=====> Scorpion Fighter Spaceship {=====
Author: Weberson Soprano (VanHeber)
Author Site: www.antimaterya.com/3d
Date: Jan 2013

About Model
A lighweight 3d model of a fighter spaceship for Sci-fi games.
You can change the texture because PSD Layered UVmap is included.
Also is included too the Original Blender model file to change geometry.

# App 3d Editor: Blender 2.6 series.

# Aditional files:
	– Layered PSD file.
	– Original Blender file.
	– A collada file version.

# Version 1.0
	Initial 3d Model